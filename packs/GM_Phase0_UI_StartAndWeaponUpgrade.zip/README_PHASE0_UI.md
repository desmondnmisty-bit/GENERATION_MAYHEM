# Generation Mayhem — Phase 0 UI (Start Screen + Weapon Upgrade)

Flow: **StartMenu → Dockyard → (KO / family down) → WeaponUpgrade → Dockyard → …**

## Test in Editor (Unity 6000.0.28f1)
1. Open `Assets/Scenes/StartMenu.unity`, press Play. PLAY = new run, CONTINUE shows when a save exists, SETTINGS = stub, QUIT.
2. Fight in Dockyard. On KO (or loss) scrap is awarded (250 win / 100 loss) and ~5s later WeaponUpgrade opens. Esc in fight = back to Start.
3. Pick 1 card (cost in SCRAP), CONFIRM (or SKIP) → back to Dockyard. Test upgrade screen alone: open `WeaponUpgrade.unity` and Play
   (scrap 0 → set via `PlayerPrefs` key `GM_P0_scrap`, or win a round first).

Build order (File > Build Profiles): StartMenu, Dockyard, WeaponUpgrade — already set.

## Files — `Assets/Scripts/UI/`
- `GMFlow.cs` — auto-boots (no scene setup), watches `MatchDirector`, awards scrap, loads scenes, applies Vixen damage upgrades.
- `StartMenuController.cs` / `WeaponUpgradeController.cs` — uGUI built in code, Dark Logic neon look.
- `WeaponUpgradeDef.cs` — ScriptableObject (Create > Generation Mayhem > Weapon Upgrade). Put assets in `Assets/Resources/Upgrades/` to override the built-in catalog.
- `GMUpgradeData.cs` — built-in catalog (Vixen Sonic Resonator/Slingshot, Kailee Thermal Blades/K-1911, + Brianna Coil Gauntlets, Payton Gatling), `GMSave` (PlayerPrefs), `GMFlowEvents`.

## Hooks (RefBot / MedBot later — UI does not wait on them)
`GMFlowEvents.OnMatchStart(round)`, `GMFlowEvents.OnRoundEnd(round, won)`, `GMFlowEvents.OnUpgradePicked(def)`.
Combat reads bonuses with `GMSave.Bonus("Kailee", UpgradeStat.FireRate)` etc. Phase 0 only Vixen damage is auto-applied; other stats are stored and ready to wire.
Show Brianna/Payton cards: set `fighters` on the WeaponUpgrade controller object.
