GENERATION MAYHEM — INTRO CUTSCENE ART SLOTS (in play order)
Name files EXACTLY like this (PNG/JPG, 16:9, 1920x1080 ideal), put them in
Assets/Resources/Intro/ and set Texture Type = Sprite (2D and UI).
Missing files show a dark placeholder panel with the slot name.

1. kids_happy       — pictures of the kids happy
2. irs_contracts    — IRS forcing into contracts
3. phone_call       — the phone call
4. kitchen_rage     — RAGE, kitchen destroyed
5. garage_cabinet   — garage, opening the big cabinet
6. war_rig_dusty    — the war rig inside, dusty
7. strapping_in     — strapping into the rig
