// START SCREEN. PLAY / CONTINUE (if save) / SETTINGS (stub) / QUIT. No lore.
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

namespace GenerationMayhem.UI
{
    public class StartMenuController : MonoBehaviour
    {
        public string fightScene = GMFlow.FightScene;
        Text _settingsToast; float _toastUntil; Image _bolt;

        void Start()
        {
            Time.timeScale = 1f;
            var c = GMUIKit.Canvas("StartMenuCanvas", 100).transform;
            GMUIKit.Panel(c, "BG", GMUIKit.Black, Vector2.zero, Vector2.one);
            // industrial stripes
            for (int i = 0; i < 6; i++) GMUIKit.Panel(c, "Stripe" + i, new Color(1, 1, 1, 0.025f), new Vector2(0, i / 6f), new Vector2(1, i / 6f + 0.004f));
            _bolt = GMUIKit.Panel(c, "PinkBolt", GMUIKit.Pink, new Vector2(0.08f, 0.62f), new Vector2(0.92f, 0.627f));

            var title = GMUIKit.Rect(c, "Title", new Vector2(0, 0.66f), new Vector2(1, 0.9f));
            GMUIKit.Label(title, "GENERATION MAYHEM", 120, GMUIKit.Pink);
            var tag = GMUIKit.Rect(c, "Tag", new Vector2(0, 0.57f), new Vector2(1, 0.62f));
            GMUIKit.Label(tag, "DARK LOGIC  //  SOPHISTICATED BRUTALITY", 30, GMUIKit.Cyan, TextAnchor.MiddleCenter, FontStyle.Normal);

            var col = GMUIKit.Rect(c, "Buttons", new Vector2(0.5f, 0.12f), new Vector2(0.5f, 0.54f), new Vector2(-260, 0), new Vector2(260, 0));
            var v = col.gameObject.AddComponent<VerticalLayoutGroup>(); v.spacing = 22; v.childAlignment = TextAnchor.UpperCenter; v.childForceExpandHeight = false; v.childControlHeight = true; v.childControlWidth = true;

            var play = GMUIKit.Button(col, "PLAY", GMUIKit.Pink, () => { GMSave.NewGame(); GMFlow.GoFight(); });
            if (GMSave.Exists && (GMSave.Round > 1 || GMSave.Scrap > 0))
                GMUIKit.Button(col, "CONTINUE  R" + GMSave.Round, GMUIKit.Cyan, GMFlow.GoFight);
            GMUIKit.Button(col, "SETTINGS", new Color(0.7f, 0.7f, 0.75f), () => { _toastUntil = Time.unscaledTime + 1.5f; });
            GMUIKit.Button(col, "QUIT", GMUIKit.Toxic, Quit);

            var toast = GMUIKit.Rect(c, "Toast", new Vector2(0, 0.04f), new Vector2(1, 0.1f));
            _settingsToast = GMUIKit.Label(toast, "SETTINGS — COMING SOON", 28, Color.white);
            EventSystem.current?.SetSelectedGameObject(play.gameObject);
        }

        void Update()
        {
            if (_settingsToast) _settingsToast.enabled = Time.unscaledTime < _toastUntil;
            if (_bolt) { var k = 0.6f + 0.4f * Mathf.Abs(Mathf.Sin(Time.unscaledTime * 7f)) * (Random.value > 0.03f ? 1f : 0.2f); _bolt.color = GMUIKit.Pink * k; }
        }

        static void Quit()
        {
#if UNITY_EDITOR
            UnityEditor.EditorApplication.isPlaying = false;
#else
            Application.Quit();
#endif
        }
    }
}
